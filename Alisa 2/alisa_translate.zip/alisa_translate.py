from flask import Flask, request
from flask_ngrok import run_with_ngrok
import logging
import json
import requests
from geo import *

app = Flask(__name__)
run_with_ngrok(app)

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(levelname)s %(name)s %(message)s')

sessionStorage = {}


@app.route('/post', methods=['POST'])
def main():
    logging.info('Request: %r', request.json)
    response = {
        'session': request.json['session'],
        'version': request.json['version'],
        'response': {
            'end_session': False
        }
    }
    handle_dialog(response, request.json)
    logging.info('Request: %r', response)
    return json.dumps(response)


def handle_dialog(res, req):
    user_id = req['session']['user_id']

    if req['session']['new']:
        res['response']['text'] = 'Переведи слово "cлово без ковычек"'
        return
    else:
        data = req['request']['nlu']['tokens']
        res['response']['text'] = 'Неправильный запрос'
        if len(data) == 3 and data[0].lower() == "переведи" and data[1].lower() == 'слово':
            params = {
                'key': 'trnsl.1.1.20200510T063837Z.9d452e880ab33516.ac524792a3446e1ae81742675030dde8fa99134e',
                'text': data[2],
                'lang': 'en'
            }
            info = requests.get("https://translate.yandex.net/api/v1.5/tr.json/translate", params=params).json()
            res['response']['text'] = info['text'][0]
        return



if __name__ == '__main__':
    app.run()