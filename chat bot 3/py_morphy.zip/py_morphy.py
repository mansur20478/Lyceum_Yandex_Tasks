from const import TOKEN
import pymorphy2
from discord.ext import commands


bot = commands.Bot(command_prefix="!#")


@bot.event
async def on_ready():
    print(f'{bot.user.name} has connected to Discord!')


@bot.command(name="inf")
async def to_inf(ctx, text):
    morph = pymorphy2.MorphAnalyzer()
    await ctx.send(morph.parse(text)[0].normal_form)


@bot.command(name="alive")
async def alive(ctx, text):
    message = "Не существительное"
    morph = pymorphy2.MorphAnalyzer()
    data = morph.parse(text)
    for word in data:
        if 'NOUN' in word.tag:
            if 'anim' in word.tag:
                message = f'{text} живой'
            else:
                message = f'{text} не живой'
    await ctx.send(message)


@bot.command(name='morph')
async def morph(ctx, text):
    morph = pymorphy2.MorphAnalyzer()
    await ctx.send(morph.parse(text)[0].tag.cyr_repr)


@bot.command(name='numerals')
async def numerals(ctx, text, num):
    morph = pymorphy2.MorphAnalyzer()
    await ctx.send(f'{num} {morph.parse(text)[0].make_agree_with_number(int(num)).word}')


@bot.command(name='noun')
async def noun(ctx, text, form, num):
    morph = pymorphy2.MorphAnalyzer()
    data = morph.parse(text)[0]
    if 'NOUN' in data[1]:
        if num == 'single':
            message = data.inflect({form})[0]
        else:
            message = data.inflect({form, 'plur'})[0]
    else:
        message = f'{text} не существительное'
    await ctx.send(message)


bot.run(TOKEN)
