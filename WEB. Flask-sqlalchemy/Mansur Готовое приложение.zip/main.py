import flask, datetime

from flask import Flask, render_template, request, redirect, make_response, url_for
from data import db_session
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash
from wtforms.fields.html5 import EmailField
from wtforms.fields import StringField, PasswordField, SubmitField, IntegerField, BooleanField
from wtforms.validators import DataRequired
from data.users import User
from data.jobs import Jobs
from flask_wtf import FlaskForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)


class RegisterForm(FlaskForm):
    email = EmailField('Login/email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    password_again = PasswordField('Repeat password', validators=[DataRequired()])
    surname = StringField('Surname', validators=[DataRequired()])
    name = StringField('Name', validators=[DataRequired()])
    age = IntegerField('Age', validators=[DataRequired()])
    position = StringField('Position', validators=[DataRequired()])
    speciality = StringField('Speciality', validators=[DataRequired()])
    address = StringField('Address', validators=[DataRequired()])
    submit = SubmitField('Submit')


class JobAddForm(FlaskForm):
    title = StringField('Job Title', validators=[DataRequired()])
    team_leader = IntegerField('Team Leader id', validators=[DataRequired()])
    work_size = IntegerField('Work Size', validators=[DataRequired()])
    collaborators = StringField('Collaborators', validators=[DataRequired()])
    is_finished = BooleanField('Is job finished?')
    submit = SubmitField('Submit')


def get_boss(id):
    session = db_session.create_session()
    jobby = session.query(Jobs).filter(Jobs.id == id).first()
    return jobby


class JobEditForm(FlaskForm):
    title = StringField('Job Title', validators=[DataRequired()])
    team_leader = IntegerField('Team Leader id', validators=[DataRequired()])
    work_size = IntegerField('Work Size', validators=[DataRequired()])
    collaborators = StringField('Collaborators', validators=[DataRequired()])
    is_finished = BooleanField('Is job finished?')
    submit = SubmitField('Submit')


class LoginForm(FlaskForm):
    email = EmailField('Email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Remember me')
    submit = SubmitField('Submit')


@app.route("/addjob", methods=['POST', 'GET'])
@login_required
def add_job():
    form = JobAddForm()
    if form.validate_on_submit():
        job = Jobs(
            team_leader=form.team_leader.data,
            job=form.title.data,
            work_size=form.work_size.data,
            collaborators=form.collaborators.data,
            is_finished=form.is_finished.data,
            creator=current_user.id
        )
        session = db_session.create_session()
        session.add(job)
        session.commit()
        return redirect('/')
    return render_template('add_job.html', form=form)


@app.route("/editjob/<int:id>", methods=['POST', 'GET'])
@login_required
def edit_job(id):
    form = JobEditForm()
    boss = get_boss(id)
    if current_user.id != 1 and boss.id != current_user.id and boss.team_leader != current_user.id:
        return redirect('/')
    if form.validate_on_submit():
        session = db_session.create_session()
        need = session.query(Jobs).filter(Jobs.id == id).first()
        need.team_leader = form.team_leader.data
        need.job = form.title.data
        need.work_size = form.work_size.data
        need.collaborators = form.collaborators.data
        need.is_finished = form.is_finished.data
        session.commit()
        return redirect('/')
    return render_template('edit_job.html', form=form, boss=boss)


@app.route("/")
def index():
    names = {}
    session = db_session.create_session()
    for user in session.query(User).all():
        names[user.id] = (user.surname, user.name)
    jobby = {}
    for job in session.query(Jobs).all():
        jobby[job.id] = []
        jobby[job.id].append(job.job)
        jobby[job.id].append(names[job.team_leader][0] + " " + names[job.team_leader][1])
        jobby[job.id].append(job.work_size)
        jobby[job.id].append(job.collaborators)
        if job.is_finished:
            jobby[job.id].append("Is finished")
        else:
            jobby[job.id].append("Is not finished")
        jobby[job.id].append(job.creator)
        jobby[job.id].append(job.team_leader)
        jobby[job.id].append(job.id)
    return render_template("task.html", jobby=jobby)


@app.route("/register", methods=['POST', 'GET'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация', form=form, message="Passwords do not match")
        session = db_session.create_session()
        if session.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация', form=form, message="Login exist")
        user = User(
            surname=form.surname.data,
            name=form.name.data,
            age=form.age.data,
            position=form.position.data,
            speciality=form.speciality.data,
            address=form.address.data,
            email=form.email.data,
        )
        user.set_password(form.password.data)
        session.add(user)
        session.commit()
        return render_template('register.html', title='Регистрация', form=form, message="Success")
    return render_template('register.html', title='Регистрация', form=form)


@app.route("/login", methods=['POST', 'GET'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        session = db_session.create_session()
        user = session.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route("/deletejob/<int:id>")
@login_required
def delete_job(id):
    boss = get_boss(id)
    if current_user.id == 1 or boss.id == current_user.id or boss.team_leader == current_user.id:
        print("was")
        session = db_session.create_session()
        session.query(Jobs).filter(Jobs.id == id).delete()
        session.commit()
    return redirect('/')


@login_manager.user_loader
def load_user(user_id):
    session = db_session.create_session()
    return session.query(User).get(user_id)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


if __name__ == '__main__':
    db_session.global_init("db/blogs.sqlite")
    app.run()
