from flask import Flask, render_template, url_for, redirect, request
from flask_wtf import FlaskForm
from flask_wtf.file import FileRequired
from werkzeug.utils import secure_filename
from wtforms import StringField, PasswordField, SubmitField, FileField
from wtforms.validators import DataRequired


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
photo_base = ['old_wall.png', 'kid_wall.jpeg']
cnt = 1


class MyForm(FlaskForm):
    fileName = FileField('Choose File', validators=[FileRequired()])
    submit = SubmitField('Submit')


@app.route("/<title>")
@app.route("/index/<title>")
def index(title):
    return render_template("base.html", title=title)


@app.route("/galery", methods=['POST', 'GET'])
def galery():
    form = MyForm()
    if form.validate_on_submit():
        global cnt
        photo_base.append(str(cnt) + '.png')
        with open("static/img/" + str(cnt) + '.png', "wb") as file:
            file.write(request.files['fileName'].read())
        cnt += 1
    return render_template('gallery.html', title='Красная Планета', form=form, ph=photo_base)


if __name__ == '__main__':
    app.run(port='8000', host='127.0.0.1')