from flask import Flask, render_template, url_for


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route("/<title>")
@app.route("/index/<title>")
def index(title):
    return render_template("base.html", title=title)


@app.route("/list_prof/<title>")
def list_prof(title):
    work = [
        'Военные',
        'Издательство и типография',
        'Информатика и связь',
        'Медицинские',
        'Научные',
        'Педагогические',
        'Пищевые',
        'Прочие',
        'Сельское хозяйство',
        'Сервис и обслуживание',
        'Спортивные',
        'Творческие',
        'Технические',
        'Транспортные',
        'Экономические',
        'Юридические'
    ]
    return render_template("prof.html", prof=title, work=work)


if __name__ == '__main__':
    app.run(port='8000', host='127.0.0.1')