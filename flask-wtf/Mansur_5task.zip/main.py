from flask import Flask, render_template, url_for, redirect
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired


class LoginForm(FlaskForm):
    son_user = StringField('Id астронавта', validators=[DataRequired()])
    son_pass = PasswordField('Пароль астронавта', validators=[DataRequired()])
    dad_user = StringField('Id капитана', validators=[DataRequired()])
    dad_pass = PasswordField('Пароль капитана', validators=[DataRequired()])
    submit = SubmitField('Доступ')


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route("/<title>")
@app.route("/index/<title>")
def index(title):
    return render_template("base.html", title=title)


@app.route("/login", methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        return redirect("/Granted")
    return render_template("login.html", title="Аварийный доступ", form=form)


if __name__ == '__main__':
    app.run(port='8000', host='127.0.0.1')